var nombreUsuario = prompt("Por favor, introduce tu nombre:");
//console.log("Hola " + nombreUsuario);
document.write('Hola ', nombreUsuario)
