//Se imprime en el documento 

document.write("Suma 3 + 5 = ", 3 + 5);


//Se imprime por consola

console.log('Suma 3 + 5 = ',   3 + 5);