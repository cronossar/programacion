# Carousel de Películas Estilo NETFLIX con HTML5, CSS3 y Javascript.
### [Tutorial: https://youtu.be/1ukG4FTmdWQ](https://youtu.be/1ukG4FTmdWQ)

![Carousel de Películas Estilo NETFLIX con HTML5, CSS3 y Javascript.](https://raw.githubusercontent.com/falconmasters/p-gina-estilo-netflix/carousel/img/thumb.png)

Por: [FalconMasters](http://www.falconmasters.com)