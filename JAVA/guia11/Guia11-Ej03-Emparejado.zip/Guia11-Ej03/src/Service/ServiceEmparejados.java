package Service;

import Entidad.Carta;
import Entidad.Jugador;
import Enum.Palo;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Random;
import java.util.Scanner;


/**
 * @author SashaGameDC@gmail.com
 */
public class ServiceEmparejados {
    
    private Scanner leer;
    private Random rad;
    private ArrayList<Carta>baraja;
    private ArrayList<Carta>monton;
    private ArrayList<Jugador>jugadores;

    public ServiceEmparejados() {
        this.leer = new Scanner(System.in).useDelimiter("\n");
        this.rad = new Random();
        this.baraja = new ArrayList();
        this.monton = new ArrayList();
        this.jugadores = new ArrayList();
    }
            
    public void IniciarJuego(){
        //Habiendo seleccionado el juego y tipo de mazo, se procede a llenar iniciar el juego//
        jugadores();
        //SE CREA LA BARAJA DE CARTAS//
        barajaEspañola40();
        System.out.println("Se mezclan las cartas y se reparten 5 cartas a cada jugador");
        barajar();
        repartir(jugadores.size(),5);
        int ganador = 0;
        
        do{
            for (int i = 1; i < 5; i++) {

                int posicion = 0;

                for (int j = 0; j < 4; j++) {

                    if(jugadores.get(j).getPosicion()==i){
                        posicion = j;
                    }
                }

                if(posicion>0){
                    System.out.println("Comienza el turno del " + jugadores.get(posicion).getNombre() + ".");
                }else{
                    System.out.println("Comienza tu turno.");
                }
                tomarCarta(posicion);

                if(posicion>0){

                    System.out.println("Mira sus cartas");
                }else{
                    System.out.println("Tus cartas son");
                    mostrarmano(posicion);
                }

                if(tienePareja(posicion)){

                    descartarMano(posicion);
                    System.out.println("Al jugador le quedan " + jugadores.get(posicion).getMano().size() + " cartas.");
                }else{

                    descartarJugador(posicion);
                    System.out.println("Al jugador le quedan " + jugadores.get(posicion).getMano().size() + " cartas.");
                }
                for (int j = 0; j <jugadores.get(posicion).getMano().size(); j++) {
                    System.out.print("[]");
                }
                System.out.println("");
                System.out.println("");
                
                if(jugadores.get(posicion).getMano().isEmpty()){
                    System.out.println("El " + jugadores.get(posicion).getNombre() + " se quedó sin cartas. Es el ganador");
                    ganador++;
                }
                posicion = 0;
                System.out.println("Apriete enter para pasar de turno");
                String asd = leer.next();
            }
        }while(ganador==0);
    }   
    
    public void jugadores(){
        //ESTE METODO PERMITIRA TENES LA CANTIDAD DE JUGADORES Y LA POSICION DE CADA UNO//
        System.out.println("seran 4 jugadores");
        for (int i = 0; i < 4; i++) {
            Jugador jugador = new Jugador();
            if(i==0){
                jugador.setPosicion(rad.nextInt(4)+1);
            }
            if(i>0 && jugadores.get(i-1).getPosicion()==4){
                jugador.setPosicion(1);
            }
            if(i>0 && jugadores.get(i-1).getPosicion()<4){
                int posicion = jugadores.get(i-1).getPosicion();
                jugador.setPosicion(posicion+1);
            }
            String nombre = "jugador" + jugador.getPosicion();
            jugador.setNombre(nombre);
            jugadores.add(jugador);
        }
        System.out.println("Tu posición como jugador será " + jugadores.get(0).getPosicion());
    }
    
    public void barajaEspañola40(){
        //A FUTURO HACER UN MENU QUE TE PERMITA SELECCIONAR ENTRE MAZO DE 50 O 40 SEGUN EL JUEGO//
        for (Palo aux : Palo.values()) {
    
            for (int i = 0; i < 10; i++) {
                Carta naipe = new Carta();
                if(i<7){
                    naipe.setNumero(i+1);
                    naipe.setPalo(aux);
                }else if(i==7){
                    naipe.setNumero(10);
                    naipe.setPalo(aux);
                }else if(i==8){
                    naipe.setNumero(11);
                    naipe.setPalo(aux);
                }else if(i==9){
                    naipe.setNumero(12);
                    naipe.setPalo(aux);
                }
                baraja.add(naipe);
            }
        }
    }
    
    public void barajar(){
        Collections.shuffle(baraja);
    }
    
    public void repartir(int cantjuga, int cantidad){
        for (int i = 0; i < cantjuga; i++) {
            ArrayList<Carta> mano = new ArrayList();
            for (int j = 0; j < cantidad; j++) {
               mano.add(baraja.get(0));
               baraja.remove(0);
            }
            jugadores.get(i).setMano(mano);
        }
    }
    
    public void tomarCarta(int jugador){
        
        if(baraja.size()==0){
            System.out.println("No quedan cartas en la baraja. Se tomará el montón y se mezclará para reutilizarlo");
            baraja.addAll(monton);
            monton.clear();
            barajar();
            jugadores.get(jugador).getMano().add(baraja.get(0));
            baraja.remove(0);
        }else{
            jugadores.get(jugador).getMano().add(baraja.get(0));
            baraja.remove(0);
        }
        if(jugador==0){
            System.out.println("Tomas una carta de la baraja");
        }else{
            System.out.println("Toma una carta de la baraja");
        }
    }
    
    public void mostrarmano(int jugador){
        
        for (int i = 0; i < jugadores.get(jugador).getMano().size(); i++) {
            System.out.println(jugadores.get(jugador).getMano().get(i));
        }
    }
    
    public boolean tienePareja(int jugador){
        int cont = 0;
        for (int i = 0; i < jugadores.get(jugador).getMano().size(); i++) {
            
            for (int j = (i+1); j < jugadores.get(jugador).getMano().size();j++) {
                if(jugadores.get(jugador).getMano().get(i).getNumero() == jugadores.get(jugador).getMano().get(j).getNumero()){
                    
                    cont++;
                    if(jugador>0){
                        int repetido = jugadores.get(jugador).getMano().get(j).getNumero();
                        jugadores.get(jugador).setPuntos(repetido);
                    }else{
                        System.out.println("Usted tiene una pareja de " + jugadores.get(jugador).getMano().get(j).getNumero());                        
                    }
                }
            }
        }
        if(jugador>0){

            System.out.println("Acomoda sus cartas.");
        }
        return cont>0;
    }
      
    public void descartarMano(int jugador){
        
        ArrayList<Carta> mano = jugadores.get(jugador).getMano();
        ArrayList<Carta> mano2 = new ArrayList();
        int cont = 0;
        int descarte;
        if(jugador==0){
            boolean descartado = true;
            int cont2 = 0;
            do{
                System.out.println("Ingrese el numero a descartar");
                descarte = leer.nextInt();
                for (int i = 0; i < mano.size(); i++) {
                    if(mano.get(i).getNumero()==descarte){
                        cont2++;
                    }
                }
                if (cont2<2){
                    System.out.println("El valor ingresado no tiene pareja. Ingrese un numero que tenga pareja");
                }else{
                    descartado = false;
                } 
            }while(descartado);
            System.out.println("Cartas descartas.");
            System.out.println("");
            
        }else{
            descarte = jugadores.get(jugador).getPuntos();
            System.out.println("El " + jugadores.get(jugador).getNombre() + " descarto dos " + descarte + " de su mano.");
        }
        
        //BUSCA DENTRO DE LA MANO DEL JUGADOR LAS CARTAS QUE SEAN IGUALES AL VALOR INGRESADO//
        for (int i = 0; i < mano.size(); i++) {
            //COMPARA SI LAS CARTAS TIENEN EL VALOR REQUERIDO//
            if(mano.get(i).getNumero()!=descarte){
                
                mano2.add(mano.get(i));
            }else{
                if(cont<2){
                    monton.add(mano.get(i));
                    cont++;
                }else{
                    mano2.add(mano.get(i));
                }
            }
        }
        //SETT LA NUEVA ARRAY SIN EL PAR DESCARTADO//
        jugadores.get(jugador).setMano(mano2);
    }

    public void descartarJugador(int jugador){
        
        if(jugador>0){
            
            System.out.print("El " + jugadores.get(jugador).getNombre() + " selecciona una carta");
            int aux = 0;
            int miraCarta;
            do{
                miraCarta = rad.nextInt(4);
                if(miraCarta!=jugador){
                    aux++;
                } 
            }while(aux==0);
            
            if(miraCarta==0){
                System.out.println(" de tu mano.");
            }else{
                System.out.println(" del " + jugadores.get(miraCarta).getNombre());
            }
            
            int carta = jugadores.get(miraCarta).getMano().size();
            int buscar = rad.nextInt(carta);
            int aux2 = 0;
            System.out.println("La carta seleccionada es un " + jugadores.get(miraCarta).getMano().get(buscar).getNumero());
            
            for (int i = 0; i < jugadores.get(jugador).getMano().size(); i++) {
                
                if(jugadores.get(miraCarta).getMano().get(buscar).getNumero()==jugadores.get(jugador).getMano().get(i).getNumero()){
                    System.out.println("Existe pareja y se descartan");
                    monton.add(jugadores.get(miraCarta).getMano().get(buscar));
                    jugadores.get(miraCarta).getMano().remove(buscar);
                    monton.add(jugadores.get(jugador).getMano().get(i));
                    jugadores.get(jugador).getMano().remove(i);
                    aux2++;
                    if(miraCarta==0){
                        System.out.println("Recibes dos cartas de penalización");
                    }else{
                        System.out.println("El " + jugadores.get(miraCarta).getNombre() + " recibe dos cartas de penalización");
                    }
                    castigo(miraCarta);
                    break;
                }
            }
                
            if(aux2==0){
                System.out.println("No existe una pareja");
            }
        }else{
            
            int aux = 0;
            System.out.println("No tienes pares. Ingresa el número de un jugador");
            for (int i = 1; i < 4; i++) {
                
                if(i==3){
                    System.out.print(jugadores.get(i).getPosicion() + ".");
                }else{
                    System.out.print(jugadores.get(i).getPosicion() + ",");
                }
            }
            System.out.println("");
            int resp;
            do{
                resp = leer.nextInt();
                if(resp==jugadores.get(1).getPosicion() || resp==jugadores.get(2).getPosicion() || resp==jugadores.get(3).getPosicion()){
                    int posicion=0;
                    for (int i = 1; i <4; i++) {
                        if(jugadores.get(i).getPosicion()==resp){
                            resp = i;
                        }
                    }
                    System.out.println("El jugador " + jugadores.get(resp).getNombre() + " tiene " 
                    + jugadores.get(resp).getMano().size() + " cartas en la mano.\n" + "Ingresa el número de la carta que quieres ver,"
                    + " contando de Izquierda a derecha.");
                    aux++;
                }else{
                    System.out.println("Le erraste de jugador. Ingresa el número correspondiente a un jugador");
                }
            }while(aux==0);
            aux=0;
            int resp2;
            do{
                resp2 = leer.nextInt();
                if(resp2>0 && resp2<=jugadores.get(resp).getMano().size()){
                    System.out.println("La carta es un " + jugadores.get(resp).getMano().get(resp2-1).getNumero());
                    aux++;
                }else{
                    System.out.println("Ingrese un valor que este dentro de la cantidad de cartas que tiene el oponenete en la mano");
                }
            }while(aux==0);
            aux=0;
            for (int i = 0; i < jugadores.get(jugador).getMano().size(); i++) {
                if(jugadores.get(resp).getMano().get(resp2-1).getNumero()==jugadores.get(jugador).getMano().get(i).getNumero()){
                    System.out.println("Tienes pareja. Te descartas");
                    monton.add(jugadores.get(resp).getMano().get(resp2-1));
                    jugadores.get(resp).getMano().remove(resp2-1);
                    monton.add(jugadores.get(jugador).getMano().get(i));
                    jugadores.get(jugador).getMano().remove(i);
                    aux++;
                    System.out.println("El " + jugadores.get(resp).getNombre() + " recibe dos cartas como castigo");
                    castigo(resp);
                    break;
                }
            }
            if(aux==0){
                System.out.println("No tenes pareja para esa carta. pasas el turno");
            }
            aux=0;
        }
    }
    
    public void castigo(int jugador){
        tomarCarta(jugador);
        tomarCarta(jugador);
    }
}       