package Entidad;

import java.util.ArrayList;

/**
 * @author SashaGameDCgmail.com
 */
public class Jugador {
    
    private String nombre;
    private int posicion;
    private int puntos;
    private ArrayList<Carta> mano;
    
    //CONSTRUCTORES//
    public Jugador() {
    }

    public Jugador(String nombre, int posicion, int puntos, ArrayList<Carta> mano) {
        this.nombre = nombre;
        this.posicion = posicion;
        this.puntos = puntos;
        this.mano = mano;
    }
    
    //SETTERS//
    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public void setPosicion(int posicion) {
        this.posicion = posicion;
    }

    public void setPuntos(int puntos) {
        this.puntos = puntos;
    }

    public void setMano(ArrayList<Carta> mano) {
        this.mano = mano;
    }
    
    //GETTERS//
    public String getNombre() {
        return nombre;
    }

    public int getPosicion() {
        return posicion;
    }

    public int getPuntos() {
        return puntos;
    }

    public ArrayList<Carta> getMano() {
        return mano;
    }

    @Override
    public String toString() {
        return nombre + ", tiene la posicion " + posicion + ", con " + puntos + " puntos y \n" + mano + " en mano";
    }
    
    
}
