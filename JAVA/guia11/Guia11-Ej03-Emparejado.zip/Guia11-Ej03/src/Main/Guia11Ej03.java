
package Main;


import Service.ServiceEmparejados;
import java.util.Random;


/**
 * @author SashaGameDC@gmail.com
 */
public class Guia11Ej03 {

    public static void main(String[] args) {
        
        ServiceEmparejados crupier = new ServiceEmparejados();
        crupier.IniciarJuego();
        Random rad = new Random();

    }
    
}