package Enum;

/**
 * @author SashaGameDC@gmail.com
 */
public enum Palo {
    
    BASTOS,COPAS,OROS,ESPADAS;
}
