/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.servicio;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;
import libreria.entidades.Autor;
import libreria.entidades.Editorial;
import libreria.entidades.Libro;
import libreria.persistencia.LibroDAO;
import libreria.persistencia.exceptions.InputException;

/**
 *
 * @author ariel
 */
public class libroService extends InputException implements ServiceMethods<Libro> {

    private autorService AS = new autorService();
    private editorialService ES = new editorialService();
    private Scanner read = new Scanner(System.in);
    private LibroDAO ldao = new LibroDAO();

    @Override
    public Libro createObject() {
        Libro book;
        int opt;
        boolean flag;
        Scanner read1 = new Scanner(System.in);
        Autor a;
        Editorial ed;
        String title;
        System.out.println("Ingrese el titulo del libro");
        title = read1.nextLine();
        title= checkInputString(title);
        System.out.println("Ingrese el anio");
        String year1 = read.nextLine();
        int year = checkInputInt(year1);
        System.out.println("Ingrese la cantidad de ejemplares");
        String cant1 = read.nextLine();
        int cant = checkInputInt(cant1);
        System.out.println("Ingrese la cant de ejemplares prestados");
        String pres1 = read.nextLine();
        int prest = checkInputInt(pres1);
        int rest = cant - prest;
        System.out.println("Alta/Baja? 1/2");
        String opt1 = read.nextLine();
        opt = checkInputInt(opt1);
        boolean alta = opt == 1;
        System.out.println("Desea crear un nuevo Autor o seleccionar uno de la lista? 1/2");
        opt1=read.nextLine();
        opt = checkInputInt(opt1);
        flag = opt == 1;
        if (flag) {
            a = AS.createObject();
        } else {
            System.out.println("Autores Disponibles");
            AS.showList();
            System.out.println("Seleccione uno.");
            a = AS.lookForString();
        }
        System.out.println("Desea crear una nueva Editorial o seleccionar una de la lista? 1/2");
        opt = read.nextInt();
        flag = opt == 1;
        if (flag) {
            ed = ES.createObject();

        } else {
            System.out.println("Editoriales Disponibles");
            ES.showList();
            System.out.println("Seleccione uno.");
            ed = ES.lookForString();
        }

        return new Libro(title, year, cant, prest, rest, alta, a, ed);

    }

    @Override
    public void creationInterface() {
        System.out.println("Cuanto libros desea crear?");
        String cant1 = read.nextLine();
        int cant = checkInputInt(cant1);
        int cont = 0;
        Libro l = null;
        do {
            l = createObject();
            ldao.create(l);
            cont++;
        } while (cont < cant);
    }

    @Override
    public void edit() {
        boolean flag = true;
        System.out.println("Ingrese el nombre del libro que desea editar");
        String name = read.nextLine();
        Libro l = ldao.find(name);
        String opt2;
        do {

            System.out.println("Que desea editar?");
            System.out.println("1. Titulo");
            System.out.println("2. Alta");
            System.out.println("3. Autor");
            System.out.println("4. Editorial");
            System.out.println("5. Ejemplares");
            System.out.println("6. Ejemplares prestados");
            System.out.println("7. Anio de publicacion");
            System.out.println("8. Salir");

            int opt1;
            boolean flag1;

            int opt = read.nextInt();
            switch (opt) {
                case 1:
                    System.out.println("Ingrese el nuevo titulo");
                   // read.nextLine();
                    String title = read.nextLine();
                    title=checkInputString(title);
                    l.setTitulo(title);
                    ldao.update(l);
                    System.out.println("Libro Actualizado");

                    break;
                case 2:
                    System.out.println("Alta/Baja? 1/2");
                    opt2 = read.nextLine();
                    opt1 = checkInputInt(opt2);
                    boolean newAlta = opt1 == 1;
                    l.setAlta(newAlta);
                    ldao.update(l);
                    System.out.println("Libro Actualizado");

                    break;
                case 3:
                    System.out.println("Desea crear un nuevo autor o seleccionar otro? Opc. 1 para nuevo 2 para sel");
                    opt2 = read.nextLine();
                    opt1 = checkInputInt(opt2);
                    flag1 = opt1 == 1;
                    if (flag) {
                        Autor a = AS.createObject();
                        l.setAutor(a);
                        ldao.update(l);
                        System.out.println("Libro Actualizado");

                    } else {
                        Autor a = AS.lookForString();
                        l.setAutor(a);
                        ldao.update(l);
                        System.out.println("Libro Actualizado");

                    }
                    break;
                case 4:
                    System.out.println("Desea crear una nueva Editorial o seleccionar otra? Opc. 1 para nuevo 2 para sel");
                    opt2 = read.nextLine();
                    opt1 = checkInputInt(opt2);
                    flag1 = opt1 == 1;
                    if (flag1) {
                        Editorial ed = ES.createObject();
                        l.setEditorial(ed);
                        ldao.update(l);
                        System.out.println("Libro Actualizado");

                    } else {
                        Editorial ed = ES.lookForString();
                        l.setEditorial(ed);
                        ldao.update(l);
                        System.out.println("Libro Actualizado");

                    }
                    break;
                case 5:
                    System.out.println("Ingrese la cantidad de ejemplares actualizado");
                    opt2 = read.nextLine();
                    int cant = checkInputInt(opt2);
                    l.setEjemplares(cant);
                    int ejRestantes = l.getEjemplares() - l.getEjemplaresPrestados();
                    l.setEjemplaresRestantes(ejRestantes);
                    ldao.update(l);
                    System.out.println("Cantidad de ejemplares Actualizada");
                    break;
                case 6:
                    System.out.println("Ingrese la nueva cantidad de Ejemplares. Cantidad de ejemplares actuales (No prestados) " + l.getEjemplares() + " Prestados " + l.getEjemplaresPrestados());
                    opt2=read.nextLine();
                    int prestamos = checkInputInt(opt2);
                    if (prestamos < l.getEjemplares()) {
                        l.setEjemplaresPrestados(prestamos);
                        int ejRest = l.getEjemplares() - l.getEjemplaresPrestados();
                        l.setEjemplaresRestantes(ejRest);
                        ldao.update(l);
                        System.out.println("Libro Actualizado");
                    } else {
                        do {
                            System.out.println("La cantidad de ejemplares prestados es mayor a la cant de ejemplares. Ingrese una cantidad valida");
                            prestamos = read.nextInt();
                        } while (prestamos > l.getEjemplares());
                    }

                    break;
                case 7:
                    System.out.println("Ingrese el nuevo anio");
                    opt2=read.nextLine();
                    
                    int anio = checkInputInt(opt2);
                    l.setAnio(anio);
                    ldao.update(l);
                    System.out.println("Libro Actualizado");
                    break;
                case 8:
                    flag = false;
                    break;
            }
        } while (flag);
    }

    @Override
    public Libro lookForString() {
        System.out.println("Ingrese el titulo del libro que desea buscar");
        //read.nextLine();
        String name = read.nextLine();
        name = checkInputString(name);
        Libro l = ldao.find(name);

        return l;
    }

    public List<Libro> lookForStrings() {
        System.out.println("Ingrese el titulo, editorial y/o autor del libro que desea buscar");
        List<Libro> list = ldao.showTable();
        Iterator<Libro> it = list.iterator();
        String name = read.nextLine();
        name = checkInputString(name);
        List<Libro> listBooks = new ArrayList<>();
        Libro l = null;
        while (it.hasNext()) {
            Libro libro = it.next();
            Autor a = libro.getAutor();
            Editorial ed = libro.getEditorial();
            if (name.toLowerCase().equals(libro.getTitulo().toLowerCase())) {
                l = ldao.find(name);
                listBooks.add(l);
            } else if (name.toLowerCase().equals(a.getNombre().toLowerCase())) {
                listBooks = ldao.findByAutor(a);

            } else if (name.toLowerCase().equals(ed.getNombre().toLowerCase())) {
                listBooks = ldao.findByEd(ed);

            }
        }

        return listBooks;
    }

    @Override
    public Libro lookForId() {
        System.out.println("Ingrese el isbn del libro que desea buscar");
        String id1= read.nextLine();
      
        int id = checkInputInt(id1);
        Libro l = ldao.findById(id);
        return l;
    }

    @Override
    public boolean isDuplicated(String name) {
        List<Libro> libros = ldao.showTable();
        boolean retorno = false;

        for (Libro libro : libros) {
            if (libro.getTitulo().equals(name)) {
                retorno = true;
                break;
            } else {
                retorno = false;
            }
        }

        return retorno;
    }

    @Override
    public void deleteObject() {
        Libro l =lookForString();
        ldao.delete(l);
    }

    @Override
    public void showList() {
        List<Libro> aux = ldao.showTable();
        for (Libro l : aux) {
            System.out.println(l);
        }
    }

    @Override
    public String checkInputString(String obj) {
        String aux = obj;

        do {
            if (isNullInput(obj)) {
                System.out.println("Ingrese un valor valido");
                aux = read.nextLine();
            } 
        } while (isNullInput(aux));
        return aux;
    }

    @Override
    public int checkInputInt(String obj) {
         String aux = obj;
        int newInt = 0;
        do {
            if (isIntInput(obj)) {
                System.out.println("Ingrese un valor valido");
                aux = read.nextLine();
            
            }
        } while (isIntInput(aux) && !isDuplicated(obj));
         newInt = Integer.parseInt(aux);
        return newInt;
    }

}
