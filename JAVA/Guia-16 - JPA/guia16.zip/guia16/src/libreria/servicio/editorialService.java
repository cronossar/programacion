/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.servicio;

import java.util.List;
import libreria.entidades.Editorial;
import java.util.Scanner;
import libreria.persistencia.EditorialDAO;
import libreria.persistencia.exceptions.InputException;

/**
 *
 * @author ariel
 */
public class editorialService extends InputException implements ServiceMethods<Editorial> {

    private Scanner read = new Scanner(System.in);
    private EditorialDAO edao = new EditorialDAO();
  

    @Override
    public Editorial createObject() {
        Editorial ed;
        System.out.println("Ingrese el nombre de la editorial");
        String name = read.nextLine();
        name = checkInputString(name);
        // read.nextLine();
        if (isDuplicated(name)) {
            do {
                System.out.println("La editorial ya existe, ingrese otro nombre");
                name = read.nextLine();
                name = checkInputString(name);
            } while (isDuplicated(name));

        }
        System.out.println("Alta/Baja? 1,2");
        String option;
        option=read.nextLine();
        int input = checkInputInt(option);
        boolean alta = input == 1;

        ed = new Editorial(name, alta);

        edao.create(ed);
        return ed;
    }

    @Override
    public void creationInterface() {
        int cont = 0;
        String cantString;
        int cant;
        System.out.println("Cuantas Editoriales desea crear? Ingrese un numero entero");
        cantString=read.nextLine();
        cant = checkInputInt(cantString);
        do {
            createObject();

            cont++;
        } while (cont < cant);
    }

    @Override
    public void edit() {
        System.out.println("Ingrese la editorial que desea editar");
        String name;
        boolean newAlta = false;
        int op = 0;
        char opt;

        Editorial ed;
        name =read.nextLine();
        name = checkInputString(name);
        
        ed = edao.find(name);
        System.out.println("Desea cambiar el nombre? Y/N");
        opt = read.nextLine().toLowerCase().charAt(0);

        if (opt == 'y') {
            System.out.println("Ingrese el nuevo nombre");
            name = read.nextLine();
            name = checkInputString(name);
            ed.setNombre(name);
        }
        System.out.println("Desea cambiar el Alta? Y/N");
        opt = read.nextLine().toLowerCase().charAt(0);
        if (opt == 'y') {
            System.out.println("Alta/Baja? 1,2");
            String optionString = read.nextLine();
            op = checkInputInt(optionString);
            
            newAlta = op == 1;
            ed.setAlta(newAlta);
        }

        edao.update(ed);
        System.out.println("Lista Actualizada");

    }

    @Override
    public Editorial lookForString() {
        Editorial ed;
        System.out.println("Ingrese el nombre de la editorial que desea buscar");
        String name = read.next();
        ed = edao.find(name);
        return ed;
    }

    @Override
    public Editorial lookForId() {
        Editorial ed;
        System.out.println("ingrese el id de la editorial");
        int input = read.nextInt();
        ed = edao.findById(input);
        return ed;
    }

    @Override
    public boolean isDuplicated(String name) {
        List<Editorial> editoriales = edao.showTable();
        boolean retorno = false;

        for (Editorial ed : editoriales) {
            if (name.toLowerCase().equals(ed.getNombre().toLowerCase())) {
                retorno = true;
                break;
            } else {
                retorno = false;
            }
        }

        return retorno;
    }

    @Override
    public void deleteObject() {
        Editorial ed;
        System.out.println("Ingrese el nombre de la editorial que desea eliminar");
        String name = read.next();
        ed = edao.find(name);
        edao.delete(ed);
    }

    @Override
    public void showList() {
        List<Editorial> aux;
        aux = edao.showTable();
        for (Editorial e : aux) {
            System.out.println("Nombre: " + e.getNombre() + " alta: " + e.getAlta() + " id: " + e.getId());
        }
    }

    @Override
    public String checkInputString(String obj) {
        String aux = obj;

        do {
            if (isNullInput(obj)) {
                System.out.println("Ingrese un valor valido");
                aux = read.nextLine();
            }
        } while (isNullInput(aux));
        return aux;
    }

    @Override
    public int checkInputInt(String obj) {
        String aux = obj;
        int newInt = 0;
        do {
            if (isIntInput(obj)) {
                System.out.println("Ingrese un valor valido");
                aux = read.nextLine();
            
            }
        } while (isIntInput(aux) && !isDuplicated(obj));
         newInt = Integer.parseInt(aux);
        return newInt;
        
    }

}
