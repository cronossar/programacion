/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.servicio;

import java.util.List;
import java.util.Scanner;
import libreria.entidades.Autor;
import libreria.persistencia.AutorDAO;
import libreria.persistencia.exceptions.InputException;

/**
 *
 * @author ariel
 */
public class autorService extends InputException implements ServiceMethods<Autor> {

    private AutorDAO adao = new AutorDAO();
    private Scanner read = new Scanner(System.in).useDelimiter("\n");

    @Override
    public Autor createObject() {
        String name;
        int op1;
        Autor a;
        boolean alta;
        System.out.println("Ingrese el nombre del autor");
        name = read.nextLine();
        name = checkInputString(name);

        if (isDuplicated(name)) {
            do {
                System.out.println("El Autor ya existe, ingrese otro nombre");
                name = read.nextLine();
                name = checkInputString(name);
                read.nextLine();
            } while (isDuplicated(name));
        }
        System.out.println("Alta/Baja? 1,2");
        //read.nextLine();
        String opt = read.nextLine();
        op1 = checkInputInt(opt);
        alta = op1 == 1;
        a = new Autor(name, alta);
        adao.create(a);

        return a;
    }

    @Override
    public void creationInterface() {
        int cont = 0;
        int opt = 0;
        String opt1;

        System.out.println("Cuantos Autores desea crear?");
        opt1 = read.nextLine();
        opt = checkInputInt(opt1);
        do {
            createObject();

            cont++;
        } while (cont < opt);

    }

    @Override
    public void edit() {
        System.out.println("Ingrese el autor que desea editar");
        String name;
        boolean newAlta = false;
        int op = 0;
        char opt;

        Autor a;
        name = checkInputString(read.next());
        read.nextLine();
        a = adao.find(name);
        System.out.println("Desea cambiar el nombre? Y/N");
        opt = read.nextLine().toLowerCase().charAt(0);

        if (opt == 'y') {
            System.out.println("Ingrese el nuevo nombre");
            name = checkInputString(read.next());
            read.nextLine();
            a.setNombre(name);
        }
        System.out.println("Desea cambiar el Alta? Y/N");
        opt = read.nextLine().toLowerCase().charAt(0);
        if (opt == 'y') {
            System.out.println("Alta/Baja? 1,2");
            op = read.nextInt();
            read.nextLine();
            newAlta = op == 1;
            a.setAlta(newAlta);
        }

        adao.update(a);
        System.out.println("Lista Actualizada");
    }

    @Override
    public Autor lookForString() {
        System.out.println("Ingrese el autor que desea buscar");
        String name;
        Autor a;
        name = checkInputString(read.next());
        read.nextLine();
        a = adao.find(name);
        return a;
    }

    @Override
    public Autor lookForId() {
        int id;
        Autor a;
        String option;
        System.out.println("Ingrese el id del autor");
        option = read.nextLine();
        id = checkInputInt(option);
        read.nextLine();
        a = adao.findById(id);
        System.out.println("Resultado de la busqueda");
        return a;
    }

    @Override
    public boolean isDuplicated(String name) {
        List<Autor> autores = adao.showTable();
        boolean retorno = false;

        for (Autor a : autores) {
            if (a.getNombre().equals(name)) {
                retorno = true;
                break;
            } else {
                retorno = false;
            }
        }

        return retorno;
    }

    @Override
    public void showList() {
        List<Autor> aux;
        aux = adao.showTable();
        for (Autor a : aux) {
            System.out.println("Nombre: " + a.getNombre() + " Alta: " + a.getAlta() + " id: " + a.getId());
        }

    }

    @Override
    public void deleteObject() {
        System.out.println("Ingrese el nombre del autor que desea eliminar");
        String name;
        Autor a;
        name = read.next();
        read.nextLine();
        a = adao.find(name);
        adao.delete(a);
    }

    @Override
    public String checkInputString(String obj) {
        String aux = obj;

        do {
            if (isNullInput(obj)) {
                System.out.println("Ingrese un valor valido");
                aux = read.nextLine();
            } 
        } while (isNullInput(aux));
        return aux;
    }

    @Override
    public int checkInputInt(String obj) {
        String aux = obj;
        int newInt = 0;
        do {
            if (isIntInput(obj)) {
                System.out.println("Ingrese un valor valido");
                aux = read.nextLine();
            } 
        } while (isIntInput(aux) && !isDuplicated(obj));
        newInt = Integer.parseInt(aux);
        return newInt;
    }

//    public boolean existEntity(String obj){
//        List<Autor> autores = adao.showTable();
//        for (Autor autor :autores){
//            if (autor.equals(obj)) {
//                
//            }
//        } 
//    }
}
