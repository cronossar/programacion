/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package libreria.servicio;

import java.util.List;

/**
 *
 * @author ariel
 * @param <T>
 */
public interface ServiceMethods<T> {
    
    public T createObject();
    
    public String checkInputString(String obj);
    
    public int checkInputInt(String obj) ;
    
    public void creationInterface();
    
    public void edit();
    
    public T lookForString();
    
    public T lookForId();
    
    public boolean isDuplicated(String name);
    
    public void deleteObject();
    
    public void showList();
    
}
