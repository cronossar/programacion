/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.servicio;

import java.util.List;
import java.util.Scanner;
import libreria.entidades.Libro;

/**
 *
 * @author ariel
 */
public class serviceLibreria {
    
    private Scanner read = new Scanner(System.in);
    private autorService as = new autorService();
    private editorialService ed = new editorialService();
    private libroService ls = new libroService();
    /*Crear los métodos para persistir entidades en la base de datos librería
7) Crear los métodos para dar de alta/bajo o editar dichas entidades.
8) Búsqueda de un Autor por nombre.
9) Búsqueda de un libro por ISBN.
10) Búsqueda de un libro por Título.
11) Búsqueda de un libro/s por nombre de Autor.
12) Búsqueda de un libro/s por nombre de Editorial.
13) Agregar las siguientes validaciones a todas las funcionalidades de la aplicación:
*/
    public void menu(){
        boolean flag=true;
        do {
            System.out.println("MENU");
            System.out.println("----------------------------------------");
            System.out.println("1. Ingresar al apartado de PERSISTENCIA ");
            System.out.println("2. Editar entidades");
            System.out.println("3. Buscar el Autor por nombre");
            System.out.println("4. Buscar libro por ISBN");
            System.out.println("5. Buscar libro por titulo, autor, y/o editorial");
            System.out.println("6. Eliminar entidades");
            System.out.println("7. Buscar Autor por nombre");
            System.out.println("8. Buscar Editorial por nombre");
            System.out.println("9. Mostrar entidades");
            System.out.println("10. Salir.");
            System.out.println("----------------------------------------");
            int opt =read.nextInt();
            switch (opt) {
                case 1:
                    persistence();
                    break;
                case 2:
                    editUnit();
                    break;
                case 3:
                    System.out.println(as.lookForString());
                    break;
                case 4:
                    System.out.println(ls.lookForId());
                    break;
                case 5:
                    show(ls.lookForStrings());
                    break;
                case 6:
                   delete();
                    break;
                case 7:
                    as.lookForString();
                    break;
                case 8:
                    ed.lookForString();
                    break;
                case 9:
                    showEntities();
                    break;
                case 10 :
                    flag=false;
                    break;

            }
        } while (flag);
    }
    
    public void persistence(){
        System.out.println("UNIDAD DE PERSISENCIA");
        System.out.println("---------------------");
        System.out.println("Que entidades desea crear?");
        System.out.println("--------------------------");
        System.out.println("1. Autor");
        System.out.println("2. Editorial");
        System.out.println("3. Libro");
        System.out.println("--------------------------");
        int opt = read.nextInt();
        switch(opt){
            case 1:
                as.creationInterface();
                break;
            case 2:
                ed.creationInterface();
                break;
            case 3:
                ls.creationInterface();
                break;
            default:
                break;
        }
    }
    
    public void editUnit(){
        System.out.println("Ingresando al editor...");
        System.out.println("-----------------------");
        System.out.println("Que entidades desea editar?");
        System.out.println("--------------------------");
        System.out.println("1. Autor");
        System.out.println("2. Editorial");
        System.out.println("3. Libro");
        System.out.println("--------------------------");
        int opt = read.nextInt();
        switch(opt){
            case 1:
                as.edit();
                break;
            case 2:
                ed.edit();
                break;
            case 3:
                ls.edit();
                break;
            default:
                break;
        }
    }
    
    public void show(List<Libro> lista){
        for(Libro libro: lista){
            System.out.println(libro);
        }
    }
 
    public void delete(){
        System.out.println("Reciclado de Entidades...");
        System.out.println("Que entidades desea eliminar?");
        System.out.println("--------------------------");
        System.out.println("1. Autor");
        System.out.println("2. Editorial");
        System.out.println("3. Libro");
        System.out.println("--------------------------");
        int opt = read.nextInt();
        switch(opt){
            case 1:
                as.deleteObject();
                break;
            case 2:
                ed.deleteObject();
                break;
            case 3:
                ls.deleteObject();
                break;
            default:
                break;
        }
    }
    public void showEntities(){
        System.out.println("Que entidades desea mostrar?");
        System.out.println("--------------------------");
        System.out.println("1. Autores");
        System.out.println("2. Editoriales");
        System.out.println("3. Libros");
        System.out.println("--------------------------");
        int opt = read.nextInt();
        switch(opt){
            case 1:
                as.showList();
                break;
            case 2:
                ed.showList();
                break;
            case 3:
                ls.showList();
                break;
            default:
                break;
        }
    }
}
