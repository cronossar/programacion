/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package libreria;

import libreria.servicio.autorService;
import libreria.servicio.serviceLibreria;

/**
 *
 * @author ariel
 */
public class main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {

        serviceLibreria ls = new serviceLibreria();
        ls.menu();
    }
}
