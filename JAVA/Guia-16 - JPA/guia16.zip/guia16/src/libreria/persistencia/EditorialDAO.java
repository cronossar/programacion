/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.persistencia;

import java.util.List;
import javax.persistence.TypedQuery;
import libreria.entidades.Editorial;

/**
 *
 * @author ariel
 */
public class EditorialDAO extends DAO<Editorial> {

    @Override
    public Editorial findById(int id) {
        connect();
        Editorial aux;
        try{
            aux=em.find(Editorial.class,id);    
        }finally{
           disconnect();
        }
        return aux;
    }


    @Override
    public List<Editorial> showTable() {
        connect();
        List<Editorial> aux;
        try{
           aux= em.createQuery("SELECT e FROM Editorial e").getResultList();
            
        }finally{
           disconnect();
        }
        
        return aux;
    }

    @Override
    public Editorial find(String name) {
        connect();
        TypedQuery<Editorial> query;
        Editorial aux;
        try{
            query=em.createQuery("SELECT e FROM Editorial e WHERE e.nombre = :name", Editorial.class);
            query.setParameter("name", name);
            aux = query.getSingleResult();
        }finally{
           disconnect();
        }
        return aux;
    }
    
}
