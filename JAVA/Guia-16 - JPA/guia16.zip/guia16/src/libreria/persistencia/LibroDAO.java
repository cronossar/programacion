/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.persistencia;

import java.util.List;
import javax.persistence.TypedQuery;
import libreria.entidades.Autor;
import libreria.entidades.Editorial;
import libreria.entidades.Libro;

/**
 *
 * @author ariel
 */
public class LibroDAO extends DAO<Libro> {

    
    @Override
    public Libro findById(int id) {
        connect();
        Libro libro;
        try{
            libro=em.find(Libro.class,id);    
        }finally{
           disconnect();
        }
        return libro;
    }


    @Override
    public List<Libro> showTable() {
        connect();
        List<Libro> libros;
        try{
           libros= em.createQuery("SELECT l FROM Libro l").getResultList();
            
        }finally{
           disconnect();
        }
        
        return libros;
    }
    

    

    /*Crear los métodos para persistir entidades en la base de datos librería
7) Crear los métodos para dar de alta/bajo o editar dichas entidades.
8) Búsqueda de un Autor por nombre.
9) Búsqueda de un libro por ISBN.
10) Búsqueda de un libro por Título.
11) Búsqueda de un libro/s por nombre de Autor.
12) Búsqueda de un libro/s por nombre de Editorial.
13) Agregar las siguientes validaciones a todas las funcionalidades de la aplicación:
• Validar campos obligatorios.
• No ingresar datos duplicados.*/

    @Override
    public Libro find(String name) {
        connect();
        TypedQuery<Libro> query;
        Libro aux;
        try{
            query=em.createQuery("SELECT l FROM Libro l WHERE l.titulo= :name", Libro.class);
            query.setParameter("name", name);
            aux = query.getSingleResult();
        }finally{
           disconnect();
        }
        return aux;
    }
    public List<Libro> findByAutor(Autor id){
        connect();
        TypedQuery<Libro> query;
        List<Libro> aux;
        try{
            query = em.createQuery("SELECT l FROM Libro l WHERE l.autor = :id", Libro.class);
            query.setParameter("id", id);
            aux = query.getResultList();
        }finally{
        disconnect();
    }
        return aux;
    }
    
    public List<Libro> findByEd(Editorial name){
        connect();
        TypedQuery<Libro> query;
        List<Libro> aux;
        try{
            query = em.createQuery("SELECT l FROM Libro l WHERE l.editorial = :name", Libro.class);
            query.setParameter("name", name);
            aux = query.getResultList();
        }finally{
        disconnect();
    }
        return aux;
    }
    
   
}
