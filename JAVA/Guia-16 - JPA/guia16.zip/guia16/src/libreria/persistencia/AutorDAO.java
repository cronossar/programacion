/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.persistencia;


import java.util.List;
import javax.persistence.TypedQuery;
import libreria.entidades.Autor;

/**
 *
 * @author ariel
 */
public class AutorDAO extends DAO<Autor>{

    @Override
    public Autor find(String name) {
        connect();
        TypedQuery<Autor> query;
        Autor aux;
        try{
            query=em.createQuery("SELECT a FROM Autor a WHERE a.nombre = :name", Autor.class);
            query.setParameter("name", name);
            aux = query.getSingleResult();
        }finally{
           disconnect();
        }
        return aux;
    }


    @Override
    public List<Autor> showTable() {
        connect();
        List<Autor> aux;
        try{
            em.getTransaction().begin();
            aux= em.createQuery("SELECT a FROM Autor a").getResultList();
            
        }finally{
           disconnect();
        }
        
        return aux;
    }

    @Override
    public Autor findById(int id) {
        connect();
        Autor aux;
        try{
            aux=em.find(Autor.class,id);    
        }finally{
           disconnect();
        }
        return aux;
    }

 

   
    
   
}
