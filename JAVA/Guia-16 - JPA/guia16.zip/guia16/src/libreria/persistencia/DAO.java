/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.persistencia;

import java.util.List;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

/**
 *
 * @author ariel
 * @param, <T>
 * 
 */
public abstract class DAO<T> {
    
    private EntityManagerFactory emf= Persistence.createEntityManagerFactory("libreriaPU");
    protected EntityManager em=null;
   
    protected void connect(){
        if(em==null){
            this.em = this.emf.createEntityManager();
        }
    }
    
    protected void disconnect(){
        if(em.isOpen()){
            em.close();
            this.em=null;
        }
    }
    
    public void create(T object) {
        connect();
        try{
            em.getTransaction().begin();
            em.persist(object);
            em.getTransaction().commit();
        }finally{
           disconnect();
        }
    }

    protected abstract T find(String name); 
    
    protected abstract T findById(int id);
    
    public void update(T object) {
        connect();
        try{
            em.getTransaction().begin();
            em.merge(object);
            em.getTransaction().commit();
        }finally{
           disconnect();
        }
    }

    public void delete(T object) {
        connect();
        try{
            em.getTransaction().begin();
            T managedEntity = em.merge(object);
            em.remove(managedEntity);
            em.getTransaction().commit();
        }finally{
           disconnect();
        }
    }

    protected abstract List<T> showTable();
    
    
}
