/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package libreria.persistencia.exceptions;

import java.util.InputMismatchException;
import java.util.Scanner;
import java.lang.Integer;

/**
 *
 * @author ariel
 * @param <T>
 */
public abstract class InputException<T> {

    public InputException() {
    }
    private int num=0;
    private int numInput;

    public boolean isNullInput(T object) {
        boolean flag = false;
        try {
            if (object == null || (object instanceof String && ((String) object).isEmpty())) {
                throw new NullPointerException();

            } 
        } catch (NullPointerException | NumberFormatException e) {
            flag = true;
        }
        return flag;
    }

    public boolean isIntInput(T object) {
       boolean flag=false;
        try{
        if (object instanceof String){
                try{
                    this.numInput = Integer.parseInt((String) object);
                    if (numInput==0) {
                        throw new NumberFormatException(); 
                    }
                }catch(NumberFormatException e){
                    throw e;
                }
                }
            
        } catch (NullPointerException | NumberFormatException e) {
            flag = true;
        }
        return flag;
    }

    public int getNumInput() {
        return numInput;
    }
    
   
    
    public int getCorrectInt(){
        return num;
    }
    
    
            
    
}
