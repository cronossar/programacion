/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package Main;

import Entidad.Alumno;
import Entidad.Persona;
import Entidad.PersonalDeServicio;
import Entidad.Profesores;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;
/**
 *
 * @author bruno
 */
public class Main_EJ4_Extras_Herencia {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ArrayList<Persona> data = new ArrayList();
        Scanner leer = new Scanner(System.in).useDelimiter("\n");
        int op;
        boolean tb=true;
        Date d = new Date();
        // menu 
        /*
Cambio del estado civil de una persona.
• Reasignación de despacho a un empleado.
• Matriculación de un estudiante en un nuevo curso.
• Cambio de departamento de un profesor.
• Traslado de sección de un empleado del personal de servicio.
----Crear nuevo alumno, personal, o profe
Imprimir info
        */
        do{
        
        System.out.println("----------------------------");
        System.out.println("Que desea hacer?");
        //System.out.println("1. Alta de persona");
        System.out.println("1. Crear alumno");
        System.out.println("2. Crear profesor");
        System.out.println("3. Crear personal de servicio");
        System.out.println("4. Reasignacion de despacho a un empleado"); // ver si existe
        System.out.println("5. Cambio de departamento de un profesor");
        System.out.println("6. Traslado de seccion de un empleado del personal de servicio");
        System.out.println("7. Imprimir info");
        System.out.println("8. Salir");
        
        op = leer.nextInt();
        
            switch (op) {
                case 1:
                    System.out.println("Ingrese Nombre, Apellido, ID, estado civil y curso");
                    Alumno nAl = new Alumno(leer.next(), leer.next(), leer.nextInt(), leer.nextBoolean(), leer.next());
                    data.add(nAl);
                    break;
                case 2:
                    System.out.println("Ingrese Nombre, Apellido, ID, estado civil, despacho, departamento y año de ingreso");
                    Profesores nPr = new Profesores(leer.next(), leer.next(), leer.nextInt(), leer.nextBoolean(), leer.next(), leer.next());
                    d.setYear(leer.nextInt());
                    nPr.setDate(d);
                    data.add(nPr);
                    break;
                case 3:
                    System.out.println("Ingrese Nombre, Apellido, ID, estado civil, despacho, seccion y año de ingreso");
                    PersonalDeServicio nPs = new PersonalDeServicio(leer.next(), leer.next(), leer.nextInt(), leer.nextBoolean(), leer.next(), leer.next());
                    d.setYear(leer.nextInt());
                    data.add(nPs);
                    break;    
                case 4:
                    System.out.println("Ingrese id del empleado");
                    int idBuscado= leer.nextInt();
                    for (Persona persona : data) {
                        if(persona.getID()==idBuscado){
                            System.out.println("Ingrese nuevo despacho");
                            if(persona instanceof Profesores){
                                ((Profesores) persona).setDespacho(leer.next());
                            }
                            if(persona instanceof PersonalDeServicio){
                                ((PersonalDeServicio) persona).setDespacho(leer.next());
                            }
                        }
                    }
                    break;
                case 5:
                    System.out.println("Ingrese el id del profesor");
                    int idBus= leer.nextInt();
                    for (Persona persona : data) {
                        if(persona.getID()==idBus){
                            System.out.println("Ingrese nuevo departamento");
                            ((Profesores) persona).setDepartamento(leer.next());
                        }
                    }
                    break;
                case 6:
                    System.out.println("Ingrese el id del personal servicio");
                    int idBus1= leer.nextInt();
                    for (Persona persona : data) {
                        if(persona.getID()==idBus1){
                            System.out.println("Ingrese la nueva seccion");
                            ((PersonalDeServicio) persona).setSeccion(leer.next());
                        }
                    }
                    break;  
                case 7:
                    for (Persona persona : data) {
                        System.out.println(persona);
                    }
                    break;
                case 8:
                    System.out.println("Saliendo...");
                    tb=false;
                    break;    
                default:
                    System.out.println("Opcion invalida");
            }
        
        
        }while(tb);
        
    }
    
}
/*
Imprimir toda la información de cada tipo de individuo. Incluya un programa de prueba
que instancie objetos de los distintos tipos y pruebe los métodos desarrollados.
*/