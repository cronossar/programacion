package Entidad;

import java.util.Date;

public class PersonalDeServicio extends Persona {

    private String seccion;

    private String despacho;
    
    private Date anioDeIngreso;

    public void cambioDespacho(String nDespacho) {
        this.despacho = nDespacho;
    }

    public void TrasladoSeccion(String nSeccion) {
        this.seccion = nSeccion;
    }

    public PersonalDeServicio(String seccion, Date anioDeIngreso, String despacho) {
        this.seccion = seccion;
        this.anioDeIngreso = anioDeIngreso;
        this.despacho = despacho;
    }

    public PersonalDeServicio(String nombre, String apellido, int ID, boolean EC, String despacho, String seccion) {
        super(nombre, apellido, ID, EC);
        this.seccion = seccion;
        this.anioDeIngreso = anioDeIngreso;
        this.despacho = despacho;
    }

    public void setDate(Date d){
        this.anioDeIngreso = d;
    }
    
    public PersonalDeServicio() {
    }

    public String getSeccion() {
        return seccion;
    }

    public String getDespacho() {
        return despacho;
    }

    public void setDespacho(String despacho) {
        this.despacho = despacho;
    }

    public void setSeccion(String seccion) {
        this.seccion = seccion;
    }

    public Date getAnioDeIngreso() {
        return anioDeIngreso;
    }

    public void setAnioDeIngreso(Date anioDeIngreso) {
        this.anioDeIngreso = anioDeIngreso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public boolean isEC() {
        return EC;
    }

    public void setEC(boolean EC) {
        this.EC = EC;
    }

    @Override
    public String toString() {
        return "PersonalDeServicio{" + "seccion=" + seccion + ", anioDeIngreso=" + anioDeIngreso + ", despacho= " + despacho +  '}';
    }
    
    
}
