package Entidad;

public class Alumno extends Persona {

    private String curso;

    public void matriculacionEstudiante() {
    }

    public Alumno(String curso) {
        this.curso = curso;
    }

    public Alumno() {
    }

    public Alumno(String nombre, String apellido,  int ID, boolean EC, String curso) {
        super(nombre, apellido, ID, EC);
        this.curso = curso;
    }

    public String getCurso() {
        return curso;
    }

    public void setCurso(String curso) {
        this.curso = curso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public boolean isEC() {
        return EC;
    }

    public void setEC(boolean EC) {
        this.EC = EC;
    }

    @Override
    public String toString() {
        return "Alumno{" + "curso=" + curso + '}';
    }
    
    
}
