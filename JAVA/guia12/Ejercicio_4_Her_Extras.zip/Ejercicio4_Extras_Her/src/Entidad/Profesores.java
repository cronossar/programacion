package Entidad;

import java.util.Date;

public class Profesores extends Persona {

    private String departamento;
    
    private String despacho;

    private Date anioDeIngreso;

    public void cambioDespacho(String nDespacho) {
        this.despacho = nDespacho;
    }

    public void cambioDepartamento(String nDepartamento) {
        this.departamento = nDepartamento;
    }
    
//--------------
    
    
    public Profesores(String departamento, Date anioDeIngreso,String despacho) {
        this.departamento = departamento;
        this.anioDeIngreso = anioDeIngreso;
        this.despacho = despacho;
    }

    public Profesores(String nombre, String apellido, int ID, boolean EC, String despacho, String departamento) {
        super(nombre, apellido, ID, EC);
        this.departamento = departamento;
        this.anioDeIngreso = anioDeIngreso;
        this.despacho = despacho;
    }

    public Profesores() {
    }

    public void setDate(Date d){
        this.anioDeIngreso = d;
    }
    
    public String getDepartamento() {
        return departamento;
    }

    public void setDepartamento(String departamento) {
        this.departamento = departamento;
    }

    public String getDespacho() {
        return despacho;
    }

    public void setDespacho(String despacho) {
        this.despacho = despacho;
    }    
    
    public Date getAnioDeIngreso() {
        return anioDeIngreso;
    }

    public void setAnioDeIngreso(Date anioDeIngreso) {
        this.anioDeIngreso = anioDeIngreso;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public boolean isEC() {
        return EC;
    }

    public void setEC(boolean EC) {
        this.EC = EC;
    }

    @Override
    public String toString() {
        return "Profesores{" + "departamento= " + departamento + ", anioDeIngreso= " + anioDeIngreso + ", despacho= " + despacho + '}';
    }
    
    
}
