package Entidad;

public class Persona {

    protected String nombre;

    protected String apellido;

    protected int ID;

    protected boolean EC;

    public void cambioEC(boolean nEC) {
        this.EC = nEC;
    }

    public Persona() {
    }

    public Persona(String nombre, String apellido, int ID, boolean EC) {
        this.nombre = nombre;
        this.apellido = apellido;
        this.ID = ID;
        this.EC = EC;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        this.apellido = apellido;
    }

    public int getID() {
        return ID;
    }

    public void setID(int ID) {
        this.ID = ID;
    }

    public boolean isEC() {
        return EC;
    }

    public void setEC(boolean EC) {
        this.EC = EC;
    }

    @Override
    public String toString() {
        return "Persona{" + "nombre=" + nombre + ", apellido=" + apellido + ", ID=" + ID + ", EC=" + EC + '}';
    }
    
    
}
